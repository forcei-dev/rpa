import Utils from "../libs/utils.js";
import Gauge from "../libs/gauge.js";

export default {

    name: "bus_operation",
    props: ["id"],
    data: function () {
        return {
            tab_id: "bus_operation",
            bus_status_icons: {
                "BS_DR": { color: "green", icon: "directions_bus" },
                "BS_CH": { color: "cyan", icon: "ev_station" },
                "BS_MT": { color: "orange", icon: "handyman" },
                "BS_WT": { color: "grey", icon: "no_transfer" },
                "BS_AC": { color: "red", icon: "bus_alert" }
            },
            bus_list: [],
            device_id:null
        }
    },
    methods: {
        tab_click(tab_id) {

            var url = {name: tab_id, params : {id:this.id}};
            this.$router.push(url).catch(()=>{}); 

        },

        //버스 목록 바인딩
        set_bus_list(callback) {

            var path = "get_bus_list"; //city_code=38110
            var params = { "city_code":"", "customer_id": this.id };
            Utils.get_data(this, path, params, false, (status, data) => {

                if (data.length > 0) {
                    this.bus_list = data[0].json_data;

                    var item_info = {"TRIP":null, "ODO":null, "SPEED":null, "SOC":null, 
                         "BATTERY_VOLTAGE":null, "BATTERY_CURRENT":null, "CELL_MIN_TEMP":null, "CELL_MAX_TEMP":null,
                         "VCU_DTC":[]};
                    
                    this.bus_list = this.bus_list.map(v => Object.assign(v, item_info))

                    console.log(this.bus_list);
                }
                if (callback) callback();
            });

        },

        //MQTT 메세지 수신 후 데이터 처리
        set_mqtt_message(message) {

            var data = message.payloadString;
            var topic_array = message.destinationName.split("/");

            if(topic_array.length == 5) {
                var device_id = topic_array[3];
                var item_id = topic_array[4];
                
                if(item_id == "GPS") return;

                this.bus_list.forEach(bus => {
                    if(bus.device_id == device_id){
                        bus[item_id] = data;
                        this.device_id = device_id;
                        console.log(item_id, data);
                    }
                });

                console.log(this.bus_list);

            }

        },

        lost_connection(response) {
            console.log("lost_connection, Connected to " , response);
            if (response.reconnect) {
                console.log("It was a result of automatic reconnect.");
            }
        },

        get_item_data(device_id, item_id){

            var data = null;
            var filter_list = this.bus_list.filter(bus => bus.device_id > device_id);
            if(filter_list.length > 0){
                data = filter_list[0][item_id];
                console.log(device_id, item_id, data);
            }

            return data;
        }
    },
    mounted: function () {
        console.log(this.id);

        this.set_bus_list(()=>{

            if(this.bus_list.length == 0) return;

            //디바이스 ID별 MQTT 메세지 수신 후 데이터 저장
            Utils.mqtt_connect("", (mqtt)=>{

                //MQTT 메세지 수신 후 데이터 처리
                mqtt.onMessageArrived = this.set_mqtt_message;
                mqtt.onConnectionLost = this.lost_connection;

            });

        });
    },
    template: await Utils.load_html("pages/bus_operation.html")
}
