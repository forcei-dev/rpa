import Utils from "../libs/utils.js";

export default {

    name: "summary",
    data: () => ({
        title : "운영현황",
        legend_color : "#000000",
        city_list : [],
        model_list : [],
        total_status : {"00000":{}, "11010":{}, "23310":{}, "31020":{}, "31101":{}, "31240":{}, "31260":{}, "38110":{}},
        total_model : {"00000":{}, "11010":{}, "23310":{}, "31020":{}, "31101":{}, "31240":{}, "31260":{}, "38110":{}},
        total_customer : []
    }),
    methods : {

        //메뉴 초기화
        set_city_list(callback) {

            var path = "get_city_list";
            var params = "";
            Utils.get_data(this, path, params, false, (status, data) => {

                if(data.length > 0){
                    this.city_list = data.filter(obj => obj.city_code != "00000");
                }
                if(callback) callback();
            });

        },

        //메뉴 초기화
        set_model_list(callback) {

            var path = "get_model_list";
            var params = "";
            Utils.get_data(this, path, params, false, (status, data) => {

                if(data.length > 0){
                    this.model_list = data;
                }
                if(callback) callback();
            });

        },

        set_bus_status_model_summary(callback) {

            var path = "get_bus_status_model_summary";
            var params = "";
            Utils.get_data(this, path, params, false, (status, data) => {
                console.log("data", data);
                if(Object.keys(data).length > 0){
                    var bus_status_summary =  data["bus_status_summary"];
                    
                    bus_status_summary.forEach(obj => { 
                        this.total_status[obj.city_code] = obj;
                    });

                    var bus_model_summary =  data["bus_model_summary"];

                    bus_model_summary.forEach(obj => { 
                        this.total_model[obj.city_code] = obj;
                    });
                }

                if(callback) callback();
            });

        },

        set_bus_customer_summary(callback) {

            var path = "get_bus_customer_summary";
            var params = "";
            Utils.get_data(this, path, params, false, (status, data) => {

                if(data.length > 0){
                    this.total_customer = data;
                }

                if(callback) callback();
            });

        },


    },

    mounted : function() {

        this.set_city_list();
        this.set_model_list();
        this.set_bus_status_model_summary();
        this.set_bus_customer_summary();
    },

    template: await Utils.load_html("pages/summary.html")
}
