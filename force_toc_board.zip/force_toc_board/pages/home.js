import Utils from "../libs/utils.js";

export default {

    name: "home",
    data: function () {
        return {
        }
    },
    methods: {},
    mounted: function () {
        
    },
    template: await Utils.load_html("pages/home.html")
}
