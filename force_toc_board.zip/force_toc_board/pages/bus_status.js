import Utils from "../libs/utils.js";
import Gauge from "../libs/gauge.js";

export default {

    name: "bus_status",
    props: ["id"],
    data: function () {
        return {
            tab_id: "bus_status",
            bus_list: [],
            bus_status_icons: {
                "BS_DR": { color: "green", icon: "directions_bus" },
                "BS_CH": { color: "cyan", icon: "ev_station" },
                "BS_MT": { color: "orange", icon: "handyman" },
                "BS_WT": { color: "grey", icon: "no_transfer" },
                "BS_AC": { color: "red", icon: "bus_alert" }
            },
            bus_info: null,
        }
    },
    methods: {
        tab_click(tab_id) {

            var url = {name: tab_id, params : {id:this.id}};
            this.$router.push(url).catch(()=>{}); 

        },

        //버스 목록 바인딩
        set_bus_list(callback) {

            var path = "get_bus_list"; //city_code=38110
            var params = { "city_code":"", "customer_id": this.id };
            Utils.get_data(this, path, params, false, (status, data) => {

                if (data.length > 0) {
                    this.bus_list = data[0].json_data;
                }
                if (callback) callback();
            });

        },

        select_bus(bus, event) {

            if (bus != this.bus_info || this.bus_info == null) {

                //버스가 운행중일때만 상세 정보 보여줌
                if(bus.status != "BS_DR") {
                    return;
                }

                this.bus_info = bus;

            }
        },

    },
    mounted: function () {
        console.log(this.id);

        var dark = $cookies.get("DARK");
        
        var speed_range_colors = [
            [0.1, "grey"],
            [0.8, "cyan"],
            [1, "red"]
        ];

        this.set_bus_list(() => {

            var bus_plate_no_list = [];
            var bus_plate_no_series_list = [];
            var odometer_list = [];

            this.bus_list.forEach(bus => {
                bus_plate_no_list.push(bus.plate_no.substring(5, 9));
                odometer_list.push(bus.odometer);
            });

        });

        console.log("dark", dark);
        //온도 게이지 테스트
        Gauge.set_angle_gauge(echarts, "#speed_angle_gauge", 75, "Km", 0, 150, 225, -45, speed_range_colors, dark, (gauge, option) => {

            console.log(gauge, option);
            // setInterval(() => {
            //     gauge.series[0].data[0].value = 50;
            //     gauge.setOption(option, true);
            // }, 2000);

        });

        var rpm_range_colors = [
            [0.2, "grey"],
            [0.8, "cyan"],
            [1, "red"]
        ];

        Gauge.set_angle_gauge(echarts, "#rpm_angle_gauge", 7, "x 1000rpm", 0, 8, 225, -45, rpm_range_colors, dark, (gauge, option) => {

            console.log(gauge, option);
            // setInterval(() => {
            //     gauge.series[0].data[0].value = 50;
            //     gauge.setOption(option, true);
            // }, 2000);

        });
    },
    template: await Utils.load_html("pages/bus_status.html")
}
