import Utils from "../libs/utils.js";

export default {

    name: "bus_dtc_history",
    props: ["id"],
    data: function () {
        return {
            tab_id: "bus_dtc_history",
        }
    },
    methods: {
        tab_click(tab_id) {

            var url = {name: tab_id, params : {id:this.id}};
            this.$router.push(url).catch(()=>{}); 

        },
    },
    mounted: function () {
        console.log(this.id);
    },
    template: await Utils.load_html("pages/bus_dtc_history.html")
}
