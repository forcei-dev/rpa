import Utils from "../libs/utils.js";
import Gauge from "../libs/gauge.js";

export default {

    name: "bus_summary",
    props: ["id"],
    data: function () {
        return {
            title: "종합현황",
            tab_id: "bus_summary",
            chart_theme: "light",
            bus_status_icons: {
                "BS_DR": { color: "green", icon: "directions_bus" },
                "BS_CH": { color: "cyan", icon: "ev_station" },
                "BS_MT": { color: "orange", icon: "handyman" },
                "BS_WT": { color: "grey", icon: "no_transfer" },
                "BS_AC": { color: "red", icon: "bus_alert" }
            },
            customer_list : [],
            bus_list: [],
            bus_model_count: [],
            bus_status_count: [],
            bus_info: null,
            vmap: null,
            markerLayer: null,
            //창원홈플러스
            gps_x: 128.6449208744289, //128.631638,, 
            gps_y: 35.23242937923108, //35.240505,
            map_zoom: 12.5,
            max_width: 0
        }
    },
    methods: {
        tab_click(tab_id) {

            var url = {name: tab_id, params : {id:this.id}};
            this.$router.push(url).catch(()=>{}); 

        },

        //버스 목록 바인딩
        set_bus_list(callback) {

            var path = "get_bus_list"; //city_code=38110
            var params = { "city_code":"", "customer_id": this.id };
            Utils.get_data(this, path, params, false, (status, data) => {

                if (data.length > 0) {
                    this.bus_list = data[0].json_data;
                }
                if (callback) callback();
            });

        },

        //모델별 버스 카운트 바인딩
        set_model_bus_count(callback) {

            var path = "get_model_bus_count"; //city_code=38110
            var params = { "city_code":"", "customer_id": this.id };
            Utils.get_data(this, path, params, false, (status, data) => {

                if (data.length > 0) {
                    this.bus_model_count = data[0].json_data;
                }
                if (callback) callback();
            });

        },

        //상태별 버스 카운트 바인딩
        set_status_bus_count(callback) {

            var path = "get_status_bus_count"; //city_code=38110
            var params = { "city_code":"", "customer_id": this.id };
            Utils.get_data(this, path, params, false, (status, data) => {

                if (data.length > 0) {
                    this.bus_status_count = data[0].json_data;
                }
                if (callback) callback();
            });

        },

        //확대/축소처리
        zoom_card(content_id, event) {

            var max_width = $(event.target).closest(".q-card").css("max-width");

            //확대시 축소처리
            if(max_width == "100%"){
                $(event.target).closest(".q-card").css("max-width", this.max_width);
                $("#bus_summary .q-card").show();
                $("#bus_summary .map_info").removeClass("col-xs col-sm col-md");
                $("#bus_summary .map_info").addClass("col-xs-7 col-sm-7 col-md-7");
                $("#bus_summary .summary_info").show();
            }
            else{ 
                //확대처리
                //이전사이즈 저장
                this.max_width = max_width;
                //모든 bus_detail 하위의 q-card 숨기기
                $("#bus_summary .q-card").hide();
                $("#bus_summary .summary_info").hide();
                //이벤트 발생  q-card 는 확대, 보이기
                $(event.target).closest(".q-card").css("max-width","100%");
                $("#bus_summary .map_info").addClass("col-xs col-sm col-md");
                $("#bus_summary .map_info").removeClass("col-xs-7 col-sm-7 col-md-7");
                $(event.target).closest(".q-card").show();
            }

            //하위 컨텐트 아이디가 map일경우 맵사이즈 업데이트
            if(content_id == "vmap"){
                this.vmap.updateSize();
            }

        },

        //MQTT 메세지 수신 후 데이터 처리
        set_mqtt_message(message) {

            var data = message.payloadString;
            var topic_array = message.destinationName.split("/");

            if(topic_array.length == 5) {
            	var device_id = topic_array[3];
            	var item_id = topic_array[4];
            	
                //longitude, latitude : 35.240505,128.631638  : CS0010 GPS
                if(item_id != "GPS") return;

                var gps_data = data.split(",");
                var filter_bus_list = this.bus_list.filter(d => d.device_id == device_id);
                
                if(filter_bus_list.length > 0 && gps_data.length > 1){
                    var gps_x = parseFloat(gps_data[1]);
                    var gps_y = parseFloat(gps_data[0]);
    
                    //마크 추가
                    //마크 레이어 추가
                    //var markerLayer = new vw.ol3.layer.Marker(this.vmap);
                    //this.vmap.addLayer(markerLayer);

                    Utils.add_mark(vw, this.markerLayer, gps_x, gps_y, filter_bus_list[0]["plate_no"], filter_bus_list[0]["plate_no"]);
                }
                

            }

        },

        lost_connection(response) {
            console.log("lost_connection, Connected to " , response);
            if (response.reconnect) {
                console.log("It was a result of automatic reconnect.");
            }
        },

        //버스 이동 맵 처리
        set_bus_location_map() {

            //vworld map 초기화 : VMap 리턴
            this.vmap = Utils.init_vmap(vw, this.gps_x, this.gps_y, this.map_zoom);
            var center = ol.proj.transform([this.gps_x, this.gps_y], "EPSG:4326", "EPSG:900913");
            this.vmap.getView().setCenter(center);
            this.vmap.getView().setZoom(this.map_zoom);
            this.markerLayer = new vw.ol3.layer.Marker(this.vmap);
            this.markerLayer.removeAllMarker();
            this.vmap.addLayer(this.markerLayer);

        },


    },
    mounted: function () {

        this.set_model_bus_count();

        this.set_status_bus_count();

        this.set_bus_list(()=>{

            if(this.bus_list.length == 0) return;

            //버스 GPS Data(현재값) 수신
            //버스 이동 맵 처리
            this.set_bus_location_map();

            //디바이스 ID별 MQTT 메세지 수신 후 데이터 저장
            Utils.mqtt_connect("", (mqtt)=>{

                //MQTT 메세지 수신 후 데이터 처리
                mqtt.onMessageArrived = this.set_mqtt_message;
                mqtt.onConnectionLost = this.lost_connection;

            });

        });


    },
    template: await Utils.load_html("pages/bus_summary.html")
}
