import Router from "./libs/router.js";
import Utils from "./libs/utils.js";

var app = new Vue({
    el: "#q-app",
    data: function () {
        return {
            title:"BHM Total Operation Center",
            menu_title:"",
            left: false,
            right: false,
            miniState: true,
            side_menu:false,
            tree_menu: [],
            node_list:[],
            node_selected:null,
            node_expanded: ["root"],
            dark_mode:false,
            weather:{}
        }
    },
    methods: {
      home() {
        this.$router.push("/").catch(()=>{});
        this.side_menu = false;
        this.left = false;
      },
      open_page(node) {

        var url = {name: "bus_summary", params : {id:node.key}};
        this.$router.push(url).catch(()=>{}); 
        this.side_menu = false;
        this.left = false;
      },
      click_side_menu() {
        this.side_menu = !this.side_menu; 
        this.miniState = !this.miniState;
      },
      //운수사 조회
      set_city_customer_list(callback) {
        
        var path = "get_city_customer_list";
        var params = "";
        Utils.get_data(this, path, params, false, (status, data) => {

            if(data.length > 0){
                this.node_list = data[0].json_data;

                var parent_node_list = this.node_list.filter(d => d.level == 1);
                //parent_node_list.map(e => Object.assign(e, {"selectable": false, "expanded":false}))
                
                parent_node_list.forEach(e => {
                  var child_node_list = this.node_list.filter(d => d.parent_key == e.key);
                  if(child_node_list.length > 0){
                    e["children"] = child_node_list;
                  }
                  //child_node_list.map(e => Object.assign(e, {"selectable": false, "expanded":false}))
                  //this.node_expanded.push(e.key);
                });

                this.tree_menu = [
                  {
                    label: "운수사",
                    key: "root",
                    children: parent_node_list
                  }
                ]

                
            }


            if(callback) callback();
        });

      },

      select_node(key) {
 
        if(key != null){

          var select_node = this.node_list.filter(d => d.key == key)[0];
          if(select_node.level == 2){
            this.open_page(select_node);
          }
          else if(select_node.level == 1){
            this.node_expanded = ["root"];
            this.node_expanded.push(select_node.key);
          }
          
        }
        
        //this.side_menu = false;
        //this.left = false;

      },

      toggle_dark(){
        this.$q.dark.set(this.dark_mode);

        $cookies.set("DARK", this.dark_mode);
        console.log(100, $cookies.get("DARK"));
        
      },

    },
    mounted: function () {

      this.set_city_customer_list();

      Utils.get_json("weather_code.json", (status, json_data_list) => {

        Utils.get_weather("changwon", (status, data) => {

          this.weather = data.weather[0];
          this.weather.name = data.name;
          this.weather.temp_min = data.main.temp_min;
          this.weather.temp_max = data.main.temp_max;

          var filter_list = json_data_list.filter(json_data => json_data.code = this.weather.id);
          if(filter_list.length > 0){
            this.weather.ko_KR =  filter_list[0]["ko_KR"];
          }

          //this.weather["icon_path"] = "assets/icon/weather/" + this.weather.icon + ".png";
          this.weather.icon_path = "http://openweathermap.org/img/wn/" + this.weather.icon + "@2x.png";

        });
        
      });
        
        
    },
    router : Router,
})

export default app;